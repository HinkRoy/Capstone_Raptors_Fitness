Components that need to be added:
- Chatbot
- When selecting user from admin page the pages traverse to a user-detail page to update user
- User delete button in admin page
- After selecting a membership the item is added to cart
- General CSS/Bootstrap to make website look good
- Information about Raptors Fitness on the main page
  
